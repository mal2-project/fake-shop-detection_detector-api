Readme
======
1) Request your API access token https://db-dev.malzwei.at/users/ 
1) create a file called fakeshopdb_api_access_token.txt
2) copy your fake-shop db api access token into that file

Note
====
(!) DO NOT COMMITT any tokens that have either write acces to the fake-shop db (!)
