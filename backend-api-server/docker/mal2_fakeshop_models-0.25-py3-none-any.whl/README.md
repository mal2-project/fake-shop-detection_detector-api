## Prerequisites

Python >= 3.3 is required.

Then, install dependencies

    pip install -r requirements.txt

## Training and running the model
Model can be trained using:

    python train.py -c [relative path to certified sites] -f [relative path to fraudulent sites]

The accuracy metrics will be outputted in the terminal and the model will be saved in the current directory.

You can then verify the safety of a new site using:

    python verify.py -m [relative path to saved model] -v [relative path to dictionary used by model] -s [site web address]
